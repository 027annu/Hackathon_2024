package com.nc.hackathon.ipp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternalPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternalPortalApplication.class, args);
	}

}
