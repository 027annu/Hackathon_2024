package com.nc.hackathon.ipp.service;

import org.springframework.stereotype.Service;

@Service
public class DemandService {
}
